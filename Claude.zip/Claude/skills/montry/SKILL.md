---
name: brand-digitalnawa
description: Use when creating any DigitalNawa video. Loads brand identity, colors, logo, and motion system. Always load first.
---

# DigitalNawa Brand System

## Source of Truth
- Repo: https://github.com/medissaoui711/DigitalNawa-Brand-Project
- Logo source: DigitalNawa/03-Logo-Assets - NEVER generate a similar logo, use the original file only.
- Never guess colors or fonts.

## Visual Identity
- Background: #050810
- Motion Easing: cubic-bezier(0.22, 1, 0.36, 1)
- No scene longer than 3.5s

## Motion Identity (Mandatory)
1. Start: Rising Pixels, 24 pixels, Stagger 0.04s
2. Middle: Assembly to logo
3. End: "ديجيتال نوى" -> "DigitalNawa" -> "Build. Innovate. Teach." word by word

## Rules
- If logo or color is missing, STOP and ask user. Do not invent.
- Compare final frame with original logo before delivery.